<?php  require "../dbconfig.php"; 
//$_SESSION['cn']=$_SESSION['cn']=$cn;
$_SESSION['cn']=$cn;


class user
{

public function save()
{

$cn=$_SESSION['cn'];
//public $cn;

	if(!$cn)// testing the connection  
                	{  
                	    die ("Cannot connect to the database");  
                	}
			else
			{
			    echo "<br><b>connection created successfully</b><br>";
			}

 //$login_sql = "INSERT INTO ameex_user(name,pass)VALUES('$username','$password')";

$name="priya20";
$pass="priya";
//$cnfpass="Helan";


		$sql1 = "INSERT INTO ameex_user(name,pass)VALUES('$name','$pass')";
		$result = mysqli_query($cn,$sql1) or die("Error in register Inserting " . mysqli_error($cn));		  
		echo json_encode($result);
		$sqll ="select name,pass from ameex_user";
		$resultt = mysqli_query($cn,$sqll) or die("Error in ameex_avatar Inserting " . mysqli_error($cn));
		echo json_encode($resultt);
			    
		//echo json_encode($login_result);			    
	if($result) 	{
	$sql2="select uid from ameex_user where name='$name'";       
	$result1 = mysqli_query($cn,$sql2) or die("Error in selecting registerd data " . mysqli_error($cn));
        $user_data = mysqli_fetch_array($result1);
	$_SESSION['uid']=$uid=$user_data['uid'];
       // echo $uid;
	echo "<br><b>Entered data successfully<b>\n";
	echo json_encode($uid);			


				     
   			}
                     else
    		{
 		die('Could not enter data(user_table): ' . mysql_error()); 
  		} }}

class useravatar{




      public function save()
 { 
$filename=" 56b6f61c072cf.jpg";
$uri="upload/56b6f61c072cf.jpeg";
$type="image/jpeg";
$size="7.076171875";

$cn=$_SESSION['cn'];
//public $cn;

	if(!$cn)// testing the connection  
                	{  
                	    die ("Cannot connect to the database");  
                	}
			else
			{
			    echo "<br><b>connection created successfully</b><br>";
			}


             $uid=$_SESSION['uid']; 
               if($uid){
                $sql3 ="insert into ameex_user_avatar(uid,name,uri,filetype,filesize)values('$uid','$filename','$uri','$type','$size')";
		$result2 = mysqli_query($cn,$sql3) or die("Error in ameex_user_avatar Inserting " . mysqli_error($cn));
		echo json_encode($result2);
                           if(!$result2) 
				{
				      die('Could not enter data(user avatar table): ' . mysql_error()); 
   				}
   				   echo "<br><b>Entered data successfully<b>\n";
			

		$sql4 ="select * from ameex_user_avatar";
		$result3 = mysqli_query($cn,$sql4) or die("Error in ameex_avatar Inserting " . mysqli_error($cn));
		echo json_encode($result3);
		$uid_array = array();
                while($row =mysqli_fetch_assoc($result3))
    				{
				       $uid_array[] = $row;
    				}
			    echo json_encode($uid_array)."<br><br>";
			    mysqli_close($cn);                    

}
}
}

$user=new user();
$user->save();
$useravatar=new useravatar();
$useravatar->save();
?>
