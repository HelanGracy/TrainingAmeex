<?php  require "../dbconfig.php"; 
//$_SESSION['cn']=$_SESSION['cn']=$cn;
$_SESSION['cn']=$cn;
class cl
{

public function f1()
{

$cn=$_SESSION['cn'];
//public $cn;

	if(!$cn)// testing the connection  
                	{  
                	    die ("Cannot connect to the database");  
                	}
			else
			{
			    echo "<br><b>connection created successfully</b><br>";
			}

 //$login_sql = "INSERT INTO ameex_user(name,pass)VALUES('$username','$password')";
$name="priya5";
$pass="priya";
//$cnfpass="Helan";
$iname=" 56b6f61c072cf.jpg";
$uri="upload/56b6f61c072cf.jpeg";
$type="image/jpeg";
$size="7.076171875";

$sql1 = "INSERT INTO ameex_user(name,pass)VALUES('$name','$pass')";

//$sql="delete from ameex_user_profile where uid=0";
		$result = mysqli_query($cn,$sql1) or die("Error in register Inserting " . mysqli_error($cn));
		   // $login_result = mysqli_query($cn,$login_sql) or die("Error in login Inserting " . mysqli_error($cn));
		echo json_encode($result);
$sqll ="select name pass from ameex_user";
$resultt = mysqli_query($cn,$sqll) or die("Error in ameex_avatar Inserting " . mysqli_error($cn));
echo json_encode($resultt);
			    
		//echo json_encode($login_result);			    
	if($result) 	{
	$sql2="select uid from ameex_user where name='$name'";       
	$result1 = mysqli_query($cn,$sql2) or die("Error in selecting registerd data " . mysqli_error($cn));
        $user_data = mysqli_fetch_array($result1);
	$uid=$user_data['uid'];
         echo $uid;
	echo "<br><b>Entered data successfully<b>\n";
	echo json_encode($result1);			


				     
   			}
                     else
    		{
 			die('Could not enter data(user_table): ' . mysql_error()); 
  		} 

$sql3 ="UPDATE ameex_user_avatar SET name='$iname',uri='$uri',type='$type',size='$size' where uid='$uid'";
$result2 = mysqli_query($cn,$sql3) or die("Error in ameex_user_avatar Inserting " . mysqli_error($cn));
echo json_encode($result2);
                           if(!$result2) 
				{
				      die('Could not enter data(user avatar table): ' . mysql_error()); 
   				}
   				   echo "<br><b>Entered data successfully<b>\n";
			

$sql4 ="select * from ameex_user_avatar";
$result3 = mysqli_query($cn,$sql4) or die("Error in ameex_avatar Inserting " . mysqli_error($cn));
echo json_encode($result3);

			    //close the db connection
			    mysqli_close($cn);                    

}



}
$a1=new cl();
$a1->f1();

?>
