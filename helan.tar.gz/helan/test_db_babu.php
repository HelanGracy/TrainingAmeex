<?php  require "../dbconfig.php"; 
$_SESSION['cn']=$_SESSION['cn']=$cn;
class cl
{

public function f1()
{

$cn=$_SESSION['cn'];


	if(!$cn)// testing the connection  
                	{  
                	    die ("Cannot connect to the database");  
                	}
			else
			{
			    echo "<br><b>connection created successfully</b><br>";
			}

 //$login_sql = "INSERT INTO ameex_user(name,pass)VALUES('$username','$password')";
$name="Helan";
$pass="Helan";
$cnfpass="Helan";
$sql1 = "INSERT INTO ameex_user(name,pass)VALUES('$name','$pass')";
$sql2 ="INSERT INTO ameex_user_avatar(name,uri,type,size)VALUES('$name','$pass')";
//$sql="delete from ameex_user_profile where uid=0";
			    $result = mysqli_query($cn,$sql1) or die("Error in register Inserting " . mysqli_error($cn));
		   // $login_result = mysqli_query($cn,$login_sql) or die("Error in login Inserting " . mysqli_error($cn));

		echo json_encode($result);			    
		//echo json_encode($login_result);			    
				if(!$result ) 
				{
				      die('Could not enter data: ' . mysql_error()); 
   				}
   				   echo "<br><b>Entered data successfully<b>\n";
			
			    //close the db connection
			    mysqli_close($cn);
			

}



}
$a1=new cl();
$a1->f1();

?>
