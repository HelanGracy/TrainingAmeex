<?php  require "../dbconfig.php"; 
//$_SESSION['cn']=$_SESSION['cn']=$cn;
$_SESSION['cn']=$cn;
class cl
{

public function f1()
{

$cn=$_SESSION['cn'];
//public $cn;

	if(!$cn)// testing the connection  
                	{  
                	    die ("Cannot connect to the database");  
                	}
			else
			{
			    echo "<br><b>connection created successfully</b><br>";
			}


//$name="priya6";
//$pass="priya";
//$cnfpass="Helan"; 
$uid=66;
$filename=" 56b6f61c072cf.jpg";
$uri="upload/56b6f61c072cf.jpeg";
$filetype="image/jpeg";
$filesize="7.076171875";
//ALTER TABLE ameex_user_avatar
//ADD COLUMN name varchar(255),type varchar(255),
//AFTER description;


	//create an array
		if($uid){	    			    						

		$sql3 ="insert into ameex_user_avatar(uid,filename,uri,filetype,filesize)values('$uid','$uri','$filetype','$filesize')";
		$result2 = mysqli_query($cn,$sql3) or die("Error in ameex_user_avatar Inserting " . mysqli_error($cn));
		echo json_encode($result2);
       // $user_data = mysqli_fetch_array($result2);
	//$type=$user_data['uri'];
       // echo $type;
                           if(!$result2) 
				{
				      die('Could not enter data(user avatar table): ' . mysql_error()); 
   				}
   				   echo "<br><b>Entered data successfully<b>\n";
			

		//$sql4 ="select * from ameex_user_avatar";
		//$result3 = mysqli_query($cn,$sql4) or die("Error in ameex_avatar Inserting " . mysqli_error($cn));

              // $uid_array = array();
              // while($row =mysqli_fetch_assoc($result3))
    				//{
				//        $uid_array[] = $row;
    				//}
			   // echo json_encode($uid_array);

			    //close the db connection
			    mysqli_close($cn); }}}

$a1=new cl();
$a1->f1();

?>
