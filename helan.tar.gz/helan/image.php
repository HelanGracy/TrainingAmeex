
  <?php

if (isset($_REQUEST['sub'])){
$name=$_FILES['img']['name'];
$type=$_FILES['img']['type'];

$size=($_FILES['img']['size'])/1024;

$ext=end(explode('.',$name));
if (($ext == "gif")
|| ($ext == "jpeg")
|| ($ext == "jpg")
|| ($ext =="png")
&& ($size > 30))
{

$newname=uniqid();
//$ext=end(explode('.',$name));
$fullname=$newname.".".$ext;
$target="upload/";
$fulltarget=$target.$fullname;
if(move_uploaded_file($_FILES['img']['tmp_name'],$fulltarget))
{
    echo "Success<br>";
    echo "Image id: $name";
}
else
{
    echo "Failed";
}
}

else{
    echo "not successful";
    }
}
?>
<!DOCTYPE html>

<head>
<style>
#a2{
 display:relative;

}
</style>
<input type="submit" name="sub" value="submit">
<input type="file" name="img" onchange="onFileSelected(event)">
<img id="myimage" height="100">
<script>
function onFileSelected(event) {
  var selectedFile = event.target.files[0];
  var reader = new FileReader();

  var imgtag = document.getElementById("myimage");
  imgtag.title = selectedFile.name;

  reader.onload = function(event) {
    imgtag.src = event.target.result;
  };

  reader.readAsDataURL(selectedFile);
}
</script>
</html>
