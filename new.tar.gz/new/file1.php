<?php
session_start();    //$_SESSION['iname']=$iname;                      
                    //$_SESSION['type']=$type;
                   // $_SESSION['size']=$size;
                    //$_SESSION['uri']=$uri;
	                $uid=$_SESSION['uid'];
                        $name=$_SESSION['name'];
                        $pass=$_SESSION['pass'];
                        $iname=$_SESSION['iname'];
                        $type=$_SESSION['type'];
                        $size=$_SESSION['size'];
                        $uri=$_SESSION['uri'];

	include "class.user.php";
	$user = new User(); 
        $uid = $_SESSION['uid'];
	if (!$user->get_session()){
	 header("location:login.php");
	}

	if (isset($_GET['q'])){ 

	 $user->user_logout();
	 header("location:login.php");
	 }

    	 if (isset($_POST['sub']))
           {     
 
	  $iname=$_FILES['img']['name'];
	  $type=$_FILES['img']['type'];

	  $size=($_FILES['img']['size'])/1024;

	  $ext=end(explode('.',$iname));
	    if (($ext == "gif")
	       || ($ext == "jpeg")
	       || ($ext == "jpg")
	       || ($ext =="png")
	       && ($size > 30))
	         {

	           $iname=uniqid();
	           //$ext=end(explode('.',$name));
	           $fullname=$iname.".".$ext;
	           $target="upload/";
	           $uri=$target.$fullname;
		if(move_uploaded_file($_FILES['img']['tmp_name'],$uri))
		{
                 echo "Success<br>";
                 echo "Image id: $iname"."<br>";
                }
                else
                  {
                    echo "Failed";
                  }
             }
//$user->store($uid,$iname,$uri,$size,$type);
//$user->save($uid,$iname,$uri,$size,$type);
}

    if(isset($_POST['edit'])){
    $user->load($uid);
}
?>

<html>
<form name="frm" method="post" enctype="multipart/form-data">
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
	Home
	<style><!--
	 body{
	 font-family:Arial, Helvetica, sans-serif;
	 }
	 h1{
	 font-family:'Georgia', Times New Roman, Times, serif;
	 }
div#im{
 float:left;
}
div#a2 {
   width:50px; /*width of your image*/
   height:50px; /*height of your image*/
   float:left;
   margin:0; /* If you want no margin */
   padding:0; /*if your want to padding */
       }
div#sub {
float:left;

}

div#edit {
float:right;

}
	--></style> <script> 
       var text1 = document.getElementById("text1").value; 
         </script>
	<div id="container">
	<div id="header"><a href="login.php?q=logout">LOGOUT</a></div>
	<div id="main-body">
	<h1>Hello <?php $user->get_name($uid); ?></h1>
	

       	  
      
         <div id="im">
        <?php echo "<img src='$uri'  style='width:80px'/>"." "; ?>
        <input type="file" name="img"  title="<?php echo $uri;?>">  </div>
        <div id="footer"></div>

        <div id="sub">
        <input type="submit" name="sub" value="Store" /> <br>
        image name:<input type="text" name="name" id="text1" value="<?php echo $iname?>"><br>
        user name: <input type="text" name="name" id="text2" value="<?php echo $name?>"><br>
        uri:           <input type="text" name="name" id="text3" value="<?php echo $uri?>"><br>
        size:      <input type="text" name="name" id="text4" value="<?php echo $size?>"><br>
        type:      <input type="text" name="name" id="text5" value="<?php echo $type?>"><br>

       </div>
	
      <div id="edit">
      <input type="submit" name="edit" value="Edit profile"/>
       </div> 

</form>
</html>

